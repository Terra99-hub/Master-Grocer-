import MasterGrocer from "./MasterGrocer";

function App() {
  return <MasterGrocer />;
}

export default App;