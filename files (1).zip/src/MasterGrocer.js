import { useState } from "react";

export default function MasterGrocer() {
  const [cart, setCart] = useState([]);
  const [screen, setScreen] = useState("home");
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const products = [
    { id: 1, name: "Apples", price: 25, image: "🍎", category: "Fruits" },
    { id: 2, name: "Bananas", price: 15, image: "🍌", category: "Fruits" },
    { id: 3, name: "Carrots", price: 20, image: "🥕", category: "Vegetables" },
    { id: 4, name: "Broccoli", price: 30, image: "🥦", category: "Vegetables" },
    { id: 5, name: "Milk", price: 18, image: "🥛", category: "Dairy" },
    { id: 6, name: "Cheese", price: 40, image: "🧀", category: "Dairy" },
  ];

  const categories = ["All", "Fruits", "Vegetables", "Dairy"];

  const addToCart = (product) => setCart([...cart, product]);
  const removeFromCart = (i) => setCart(cart.filter((_, idx) => idx !== i));
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-white p-6 font-sans">
      {/* Header */}
      <header className="flex justify-between items-center mb-6">
        <span className="flex items-center gap-2">
          <h1 className="text-3xl font-extrabold text-primary drop-shadow">
            MasterGrocer
          </h1>
          <span className="text-success text-3xl">🥗</span>
        </span>
        <button
          className="bg-dark text-accent px-5 py-2 rounded-full font-bold flex items-center gap-2 hover:bg-primary transition"
          onClick={() => setScreen("cart")}
        >
          <span>🛒</span>
          Cart <span className="bg-accent text-dark rounded-full px-2 ml-1">{cart.length}</span>
        </button>
      </header>

      {/* Home Screen */}
      {screen === "home" && (
        <div>
          <h2 className="text-xl font-semibold mb-4 text-primary">Fresh Picks for You</h2>
          {/* Search Bar */}
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products..."
            className="w-full p-3 mb-4 rounded-full border-2 border-primary focus:outline-none focus:ring-2 focus:ring-accent bg-white text-dark placeholder:text-gray-400"
          />

          {/* Categories */}
          <div className="flex space-x-2 mb-6">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full font-bold shadow-sm border-2 transition-all
                  ${selectedCategory === cat
                    ? "bg-primary text-white border-primary"
                    : "bg-white text-dark border-dark hover:bg-accent hover:text-dark hover:border-accent"}
                `}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-3xl shadow-lg p-6 flex flex-col items-center border-2 border-dark hover:border-primary transition-all"
              >
                <div className="text-6xl mb-3">{product.image}</div>
                <h3 className="text-xl font-bold text-dark">{product.name}</h3>
                <p className="text-primary font-semibold mb-2">R {product.price}</p>
                <button
                  onClick={() => addToCart(product)}
                  className="mt-2 bg-success text-white px-4 py-2 rounded-full font-bold hover:bg-primary transition"
                >
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cart Screen */}
      {screen === "cart" && (
        <div>
          <h2 className="text-xl font-semibold mb-4 text-primary">Your Cart</h2>
          {cart.length === 0 ? (
            <p className="text-gray-500">Your cart is empty.</p>
          ) : (
            <div>
              <ul className="mb-4">
                {cart.map((item, i) => (
                  <li key={i} className="flex justify-between py-3 border-b border-primary items-center">
                    <span>
                      <span className="text-2xl">{item.image}</span>
                      <span className="ml-3 font-bold">{item.name}</span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span className="text-dark font-semibold">R {item.price}</span>
                      <button
                        className="bg-primary text-white px-2 py-1 rounded-full text-xs font-bold hover:bg-dark"
                        onClick={() => removeFromCart(i)}
                      >
                        Remove
                      </button>
                    </span>
                  </li>
                ))}
              </ul>
              <p className="font-bold mb-4 text-dark text-lg">Total: <span className="text-primary">R {total}</span></p>
              <button
                onClick={() => setScreen("checkout")}
                className="bg-accent text-dark px-5 py-2 rounded-full font-bold hover:bg-success hover:text-white transition"
              >
                Proceed to Checkout
              </button>
            </div>
          )}
        </div>
      )}

      {/* Checkout Screen */}
      {screen === "checkout" && (
        <div>
          <h2 className="text-xl font-semibold mb-4 text-primary">Checkout</h2>
          <p className="mb-2 font-bold text-dark">Delivery Address: 123 Green Street</p>
          <p className="mb-4 text-dark">Payment Method: Cash on Delivery</p>
          {/* Google Map Placeholder */}
          <div className="mb-6 border-4 border-accent rounded-2xl overflow-hidden shadow-lg">
            <iframe
              title="Delivery Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3303.922835362142!2d-118.4953386847822!3d34.01945448061281!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2bb2e5e3b7e25%3A0x1e9d1a0a7b7e7dcb!2sSanta%20Monica%20Pier!5e0!3m2!1sen!2sus!4v1632242355537!5m2!1sen!2sus"
              width="100%"
              height="250"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
          <button
            onClick={() => {
              setCart([]);
              setScreen("home");
              alert("✅ Order placed successfully!");
            }}
            className="bg-primary text-white px-5 py-2 rounded-full font-bold hover:bg-success hover:text-white transition"
          >
            Place Order
          </button>
        </div>
      )}
    </div>
  );
}