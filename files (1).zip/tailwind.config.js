/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#D90429", // Red
        accent: "#FFD600",  // Yellow
        success: "#00B140", // Green
        dark: "#000",       // Black
      },
    },
  },
  plugins: [],
};